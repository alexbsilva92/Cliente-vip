# CLIENTE VIP

Projeto Web PWA completo com duas áreas integradas (Área do Motorista e Área do Passageiro) conectado diretamente ao banco Firestore existente do projeto.

## Áreas do Sistema Web (PWA)

1. **Área do Motorista (`/` ou `/motorista`):**
   - **PWA instalável na tela inicial** (`/manifest.webmanifest`, `/sw.js`, `/icons/icon-192.png`, `/icons/icon-512.png`, `/icons/icon-maskable-512.png`).
   - Login com conta Google via Firebase Auth e identificação do motorista.
   - Painel principal com clientes ativos, total de corridas registradas, recompensas disponíveis e resgatadas.
   - Gerador de QR Code de uso único (validade de 15 minutos) com QR SVG embutido na tela, cronômetro e detecção automática de leitura.
   - Abas completas de **Clientes**, **Histórico de Corridas** e **Controle de Recompensas**, além de edição, arquivamento/restauração, exclusão e exportação de **Backup JSON** (`/api/driver/backup`).
2. **Área do Passageiro (`/ride?code=VIP-XXXX-XXXX` ou `/r/VIP-XXXX-XXXX`):**
   - Abre diretamente no navegador do celular (sem aplicativo, sem download e sem login Google).
   - Solicita apenas **Nome** e **Telefone / WhatsApp com DDD**, somando `+1 ponto` (e liberando 1 corrida grátis na cidade ao completar 10 pontos).
3. **Downloads Secundários (`/baixar`):**
   - Mantém o acesso opcional ao APK legado e código-fonte completo (`.zip`).

## Executar o servidor localmente

Requisitos: Node.js 20 ou superior.

```bash
npm install
npm start
```

O servidor escuta a porta definida em `PORT` (padrão 3000).

## Configuração obrigatória no Google Cloud Run

O servidor foi preparado para usar a identidade de execução do Cloud Run (Application Default Credentials) para que a Área do Passageiro registre corridas sem login Google, enquanto a Área do Motorista usa o token JWT oficial do Google do próprio motorista obedecendo às regras do Firestore. Não coloque chave privada de conta de serviço no APK, no ZIP público ou no código do navegador.

1. Configure o serviço Cloud Run para usar uma conta de serviço dedicada.
2. No projeto Firebase/GCP (`gen-lang-client-0491529511`) que contém o Firestore configurado em `FIRESTORE_DATABASE_ID`, conceda a essa conta o papel **Cloud Datastore User** (`roles/datastore.user`).
3. No **Firebase Console → Authentication → Settings → Authorized domains**, adicione o domínio final do site (ex.: URL do Cloud Run `.run.app` ou domínio próprio) para que o Login Google da Área do Motorista funcione no navegador.
4. Garanta que o serviço Cloud Run permita acesso HTTP público para `/`, `/motorista`, `/ride`, `/r/*`, `/manifest.webmanifest`, `/sw.js`, `/icons/*`, `/baixar`, `/api/driver/*`, `/api/ride/*` e `/cliente-vip.apk`.
5. Publique o serviço usando o `Dockerfile` incluído na raiz do projeto:

```bash
# 1. Defina o projeto GCP
gcloud config set project gen-lang-client-0491529511

# 2. (Opcional) Crie uma conta de serviço dedicada e conceda acesso ao Firestore
gcloud iam service-accounts create cliente-vip-web \
  --display-name="CLIENTE VIP Web Portal"

gcloud projects add-iam-policy-binding gen-lang-client-0491529511 \
  --member="serviceAccount:cliente-vip-web@gen-lang-client-0491529511.iam.gserviceaccount.com" \
  --role="roles/datastore.user"

# 3. Faça o deploy no Cloud Run a partir da pasta do projeto (usa o Dockerfile automaticamente)
gcloud run deploy cliente-vip \
  --source . \
  --region us-east1 \
  --allow-unauthenticated \
  --service-account="cliente-vip-web@gen-lang-client-0491529511.iam.gserviceaccount.com" \
  --set-env-vars="FIREBASE_PROJECT_ID=gen-lang-client-0491529511,FIRESTORE_DATABASE_ID=ai-studio-android-clientev-8b967b88-b5cb-4b16-94b7-b2062e126e54"
```

Após o deploy, o Cloud Run exibirá a URL pública (`https://cliente-vip-...run.app`):
- Área do Motorista: `https://SUA-URL/`
- Área do Passageiro: `https://SUA-URL/ride?code=VIP-XXXX-XXXX`
- Baixar APK no celular: `https://SUA-URL/baixar`

Se a URL gerada for diferente de `https://ais-pre-kfhsncfqq56waxbfeys57c-911794867159.us-east1.run.app` e você quiser também atualizar o app Android, atualize `WEB_BASE_URL` em `app/src/main/java/com/example/util/QrCodeDeepLink.kt` e `android:host` em `app/src/main/AndroidManifest.xml` e recompile o APK.

## Testes

```bash
npm run test:server
npm run test:rules
```

Os testes de integração dependem dos emuladores do Firebase Auth e Firestore. Use o Firebase CLI para iniciar os emuladores nas portas configuradas em `firebase.json`.

## Android

Abra a pasta do projeto no Android Studio. O projeto requer Android SDK compatível com `compileSdk 36.1` e Gradle 9.3.1. O arquivo `google-services.json` incluído pertence à configuração existente do projeto; confirme se corresponde ao Firebase correto antes de publicar uma nova versão.

## Google AI Studio

Projeto original: https://ai.studio/apps/8b967b88-b5cb-4b16-94b7-b2062e126e54
